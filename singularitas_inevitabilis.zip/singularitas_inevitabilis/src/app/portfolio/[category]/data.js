export const items = {
  Apply_Now: [
    {
      id: 1,
      title: "Donating",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/1173794/pexels-photo-1173794.jpeg",
    },
    {
      id: 2,
      title: "Missionary",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/8720899/pexels-photo-8720899.jpeg",
    },
    {
      id: 3,
      title: "Minister",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/6276729/pexels-photo-6276729.jpeg",
    }
  ],
  Sponsors: [
    {
      id: 1,
      title: "Liver Society",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/8272928/pexels-photo-8272928.jpeg",
    },
    {
      id: 2,
      title: "Kids learning tech",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/3825569/pexels-photo-3825569.jpeg",
    },
    {
      id: 3,
      title: "Strong Together Charity",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/933624/pexels-photo-933624.jpeg",
    }
  ],
  Website_Creation: [
    {
      id: 1,
      title: "ChatGPT",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/6153354/pexels-photo-6153354.jpeg",
    },
    {
      id: 2,
      title: "Next Js",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg",
    },
    {
      id: 3,
      title: "IDES",
      desc: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur vel tenetur necessitatibus unde natus perspiciatis, amet cupiditate ducimus possimus, eaque ex autem id nobis eum dolorem. Neque eveniet fugiat tenetur?",
      image:
          "https://images.pexels.com/photos/177598/pexels-photo-177598.jpeg?",
    }
  ],
};